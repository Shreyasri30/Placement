package com.reclaim.app.user;

public enum Role {
    USER, ADMIN
}
